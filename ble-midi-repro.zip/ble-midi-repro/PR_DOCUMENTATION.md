# Bug Report: Multiple definition of `BLEMIDI_ESP32::begin` when using with ESPAsyncWebServer

**Description:**

When using the `lathoub/BLE-MIDI` library in a PlatformIO project with `ESPAsyncWebServer`, a "multiple definition" linker error occurs for the `BLEMIDI_ESP32::begin` function. This is because the function is defined in the header file `hardware/BLEMIDI_ESP32.h`, and this header is included in multiple source files.

**To Reproduce:**

1. Create a new PlatformIO project for the `esp32doit-devkit-v1` board.
2. Add the following libraries to `platformio.ini`:
   ```ini
   lib_deps =
       lathoub/BLE-MIDI
       me-no-dev/ESPAsyncWebServer
       me-no-dev/AsyncTCP
       fortyseveneffects/MIDI Library@^5.0.2
   ```
3. Create a `main.cpp` file with the following content:
   ```cpp
   #include <Arduino.h>
   #include <BLEMIDI_Transport.h>
   #include <hardware/BLEMIDI_ESP32.h>
   #include <MIDI.h>
   #include <ESPAsyncWebServer.h>

   AsyncWebServer server(80);

   BLEMIDI_CREATE_DEFAULT_INSTANCE();

   void setup() {
     Serial.begin(115200);
     MIDI.begin();
     server.begin();
   }

   void loop() {
   }
   ```
4. Create a second source file `other.cpp` with the following content:
   ```cpp
   #include <Arduino.h>
   #include <BLEMIDI_Transport.h>
   #include <hardware/BLEMIDI_ESP32.h>
   #include <MIDI.h>
   #include <ESPAsyncWebServer.h>

   void dummy_function() {
     // This function is intentionally left blank.
   }
   ```
5. Build the project. The build will fail with the following "multiple definition" linker error:
    ```
    /home/jules/.platformio/packages/toolchain-xtensa-esp32/bin/../lib/gcc/xtensa-esp32-elf/8.4.0/../../../../xtensa-esp32-elf/bin/ld: .pio/build/esp32doit-devkit-v1/src/other.cpp.o: in function `bleMidi::BLEMIDI_ESP32::begin(char const*, bleMidi::BLEMIDI_Transport<bleMidi::BLEMIDI_ESP32, bleMidi::DefaultSettings>*)':
/app/ble-midi-repro/.pio/libdeps/esp32doit-devkit-v1/BLE-MIDI/src/hardware/BLEMIDI_ESP32.h:125: multiple definition of `bleMidi::BLEMIDI_ESP32::begin(char const*, bleMidi::BLEMIDI_Transport<bleMidi::BLEMIDI_ESP32, bleMidi::DefaultSettings>*)'; .pio/build/esp32doit-devkit-v1/src/main.cpp.o:/app/ble-midi-repro/.pio/libdeps/esp32doit-devkit-v1/BLE-MIDI/src/hardware/BLEMIDI_ESP32.h:125: first defined here
collect2: error: ld returned 1 exit status
*** [.pio/build/esp32doit-devkit-v1/firmware.elf] Error 1
    ```

**Fix:**

The fix is to declare the `BLEMIDI_ESP32::begin` function as `inline` in `hardware/BLEMIDI_ESP32.h`. This allows the compiler to resolve the multiple definitions at link time.

**Change:**

```diff
--- a/src/hardware/BLEMIDI_ESP32.h
+++ b/src/hardware/BLEMIDI_ESP32.h
@@ -122,7 +122,7 @@
     }
 };
 
-bool BLEMIDI_ESP32::begin(const char *deviceName, BLEMIDI_Transport<class BLEMIDI_ESP32> *bleMidiTransport)
+inline bool BLEMIDI_ESP32::begin(const char *deviceName, BLEMIDI_Transport<class BLEMIDI_ESP32> *bleMidiTransport)
 {
     _bleMidiTransport = bleMidiTransport;
 
