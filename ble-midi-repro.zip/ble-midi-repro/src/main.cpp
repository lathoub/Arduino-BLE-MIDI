#include <Arduino.h>
#include <BLEMIDI_Transport.h>
#include <hardware/BLEMIDI_ESP32.h>
#include <MIDI.h>
#include <ESPAsyncWebServer.h>

AsyncWebServer server(80);

BLEMIDI_CREATE_DEFAULT_INSTANCE();

void setup() {
  Serial.begin(115200);
  MIDI.begin();
  server.begin();
}

void loop() {
}
