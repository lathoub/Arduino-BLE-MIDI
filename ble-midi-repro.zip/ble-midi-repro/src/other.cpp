#include <Arduino.h>
#include <BLEMIDI_Transport.h>
#include <hardware/BLEMIDI_ESP32.h>
#include <MIDI.h>
#include <ESPAsyncWebServer.h>

void dummy_function() {
  // This function is intentionally left blank.
}
